import { MetadataRoute } from "next";
import { blogPosts } from "@/lib/blog-data";

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = "https://studynepal.edu.np";

  const posts = blogPosts.map((post) => ({
    url: `${baseUrl}/blog/${post.slug}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: 0.7,
  }));

  const routes = [
    "",
    "/about",
    "/contact",
    "/services",
    "/study-abroad",
    "/ielts",
    "/faq",
    "/blog",
    "/countries/canada",
    "/countries/australia",
    "/countries/uk",
    "/countries/usa",
    "/countries/japan",
    "/countries/europe",
    "/countries/new-zealand",
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "monthly" as const,
    priority: route === "" ? 1 : 0.8,
  }));

  return [...routes, ...posts];
}
