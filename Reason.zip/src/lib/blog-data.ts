export interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: "Study Guides" | "Visa Tips" | "IELTS";
  image: string;
  date: string;
  author: string;
}

export const blogPosts: BlogPost[] = [
  {
    slug: "how-to-study-in-canada-from-nepal-2026",
    title: "How to Study in Canada from Nepal in 2026: A Step-by-Step Guide",
    excerpt: "Planning your Canadian journey? Learn about SDS, GIC, and admission requirements for Nepalese students in 2026.",
    category: "Study Guides",
    image: "https://images.unsplash.com/photo-1503614472-8c93d56e92ce?q=80&w=1411&auto=format&fit=crop",
    date: "April 10, 2026",
    author: "Suman Thapa",
    content: `
      <h2>Introduction to Studying in Canada</h2>
      <p>Canada remains one of the most sought-after destinations for students from Nepal. With its high-quality education system, multicultural environment, and excellent post-study work opportunities, it's no wonder that thousands of Nepalese students choose Canada every year.</p>
      
      <h3>1. Choose Your Course and Institution</h3>
      <p>The first step is to research and select a course that aligns with your career goals and academic background. Ensure that you choose a Designated Learning Institution (DLI) in Canada.</p>
      
      <h3>2. English Proficiency Test</h3>
      <p>Most Canadian institutions require an English proficiency test like IELTS or PTE. For the SDS stream, you generally need an IELTS score of 6.0 in each band or a PTE score of 60.</p>
      
      <h3>3. Financial Planning (GIC)</h3>
      <p>A Guaranteed Investment Certificate (GIC) is a mandatory requirement for the SDS stream. Currently, the GIC amount for international students is CAD 20,635.</p>
      
      <h3>4. Apply for Admission</h3>
      <p>Once you've chosen your institution and met the requirements, submit your application for admission. You'll receive a Letter of Acceptance (LOA) if successful.</p>
      
      <h3>5. Visa Application</h3>
      <p>Submit your student visa application through the SDS or Non-SDS stream. Ensure all your documents, including your SOP and financial evidence, are in order.</p>
    `,
  },
  {
    slug: "top-5-ielts-tips-for-high-score",
    title: "Top 5 IELTS Tips for a High Band Score in the First Attempt",
    excerpt: "Achieve your target IELTS score with these proven strategies from our expert trainers in Kathmandu.",
    category: "IELTS",
    image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?q=80&w=1470&auto=format&fit=crop",
    date: "April 05, 2026",
    author: "Anita Shrestha",
    content: `
      <h2>Achieving Your Target IELTS Score</h2>
      <p>IELTS is a crucial step in your study abroad journey. A high band score not only improves your admission chances but also your visa success rate. Here are our top 5 tips for success:</p>
      
      <h3>1. Understand the Test Format</h3>
      <p>Familiarize yourself with the four sections: Listening, Reading, Writing, and Speaking. Know the types of questions and the time limits for each.</p>
      
      <h3>2. Practice Daily</h3>
      <p>Consistency is key. Spend at least 2 hours every day practicing different sections. Use official IELTS practice materials and mock tests.</p>
      
      <h3>3. Expand Your Vocabulary</h3>
      <p>Read widely and listen to diverse English accents. Learn new words and phrases in context and practice using them in your writing and speaking.</p>
      
      <h3>4. Time Management</h3>
      <p>Practice under timed conditions to build your speed and accuracy. Learn to manage your time effectively during the actual test.</p>
      
      <h3>5. Get Professional Feedback</h3>
      <p>Join an expert-led IELTS class like ours to get personalized feedback on your writing and speaking. Trainers can identify your weaknesses and help you improve.</p>
    `,
  },
  {
    slug: "visa-sop-writing-guide-nepal",
    title: "The Ultimate Visa SOP Writing Guide for Nepalese Students",
    excerpt: "Your Statement of Purpose (SOP) is critical for visa success. Learn how to write a compelling SOP that gets results.",
    category: "Visa Tips",
    image: "https://images.unsplash.com/photo-1455391727192-183753a4361a?q=80&w=1374&auto=format&fit=crop",
    date: "March 28, 2026",
    author: "Rajesh Poudel",
    content: `
      <h2>The Importance of a Strong SOP</h2>
      <p>Your Statement of Purpose (SOP) is your opportunity to tell your story to the visa officer. It's a critical document that explains your motivations, goals, and why you've chosen a particular course and country.</p>
      
      <h3>1. Be Authentic and Honest</h3>
      <p>Write your SOP in your own words. Avoid using templates or copying from others. Authenticity is highly valued by visa officers.</p>
      
      <h3>2. Clear Academic and Career Goals</h3>
      <p>Explain how your chosen course aligns with your previous academic background and your future career plans in Nepal.</p>
      
      <h3>3. Why This Specific Country and Institution?</h3>
      <p>Provide specific reasons for choosing a particular country and institution. Mention research facilities, course curriculum, and any unique features that attracted you.</p>
      
      <h3>4. Address Any Gaps or Weaknesses</h3>
      <p>If you have academic gaps or low scores, address them honestly and explain how you've overcome those challenges.</p>
      
      <h3>5. Proofread Carefully</h3>
      <p>Ensure your SOP is free from grammatical errors and typos. Get it reviewed by an expert to ensure it's professional and compelling.</p>
    `,
  },
];
